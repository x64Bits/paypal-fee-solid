import{s as e,c as r,t,a as n,b as o,i,d as a,e as c,p as l,f as s,g as d,m as u,S as m,h,r as g,T as p}from"./vendor.2e69641a.js";const f=e("main")`
  background-color: ${({theme:e})=>e.colors.bg};
  font-family: "Roboto", "Helvetica Neue", Helvetica, sans-serif, Arial !important;
  min-width: 380px;
  min-height: 390px;
  max-width: 380px;
  max-height: 450px;
  color: ${({theme:e})=>e.colors.primary};
  margin: 0 auto;
  padding: 1.25rem;
  border: ${"0"}
    ${({theme:e})=>e.colors.secondary};
  border-radius: ${"0"};
`,x=e("hr")`
  border: 0;
  border-top-width: 1px;
  border-top-style: solid;
  border-top-color: ${({theme:e})=>e.colors.separator};
  margin: 0.45rem 0;
`,v=()=>r(x,{}),A=t('<svg stroke="currentColor" fill="currentColor" strokeWidth="0" xmlns="http://www.w3.org/2000/svg"></svg>'),w=t("<title></title>");function b(e){const{src:r,attr:t={},size:l,title:s,color:d,...u}=e,m=l||"1em",h=r.c.trim();let g;return e.className&&(g=(g?g+" ":"")+e.className),d&&("none"!==r.a.stroke&&(t.stroke=d),"none"!==r.a.fill&&(t.fill=d)),(()=>{const l=A.cloneNode(!0);return n(l,t,!0,!0),n(l,u,!0,!0),o(l,"class",g),o(l,"height",m),o(l,"width",m),l.innerHTML=h,n(l,(()=>r.a),!0,!0),i(l,s&&(()=>{const e=w.cloneNode(!0);return i(e,s),e})()),a((r=>c(l,{overflow:"visible",color:e.color,...e.style},r))),l})()}var y={a:{viewBox:"0 0 24 24"},c:'<path d="M6.293 13.293L7.707 14.707 12 10.414 16.293 14.707 17.707 13.293 12 7.586z"></path>'},C={a:{viewBox:"0 0 24 24"},c:'<path d="M16.293 9.293L12 13.586 7.707 9.293 6.293 10.707 12 16.414 17.707 10.707z"></path>'};const B=e("div")`
  display: flex;
  flex-direction: column;
`,F=e("label")`
  color: ${({theme:e})=>e.colors.secondary};
  font-size: 14px;
`,M=e("div")`
  background-color: ${({theme:e})=>e.colors.fieldBg};
  border: 2px solid ${({theme:e})=>e.colors.fieldBorder};
  border-radius: 0.75rem;
  display: flex;
  flex-direction: row;
  padding: 0 0.75rem;
  align-items: center;
  margin-top: 0.75rem;
`,k=e("span")`
  font-size: 14px;
  color: ${({theme:e})=>e.colors.currency};
  margin-right: 0.3rem;
`,z=e("input")`
  background-color: ${({theme:e})=>e.colors.fieldBg};
  width: 100%;
  padding: 0.5rem 0;
  border: 0;
  font-size: 24px;
  color: ${({theme:e})=>e.colors.primary};
`,R=e("div")`
  width: 1.2rem;
  background-color: ${({theme:e})=>e.colors.fieldBorder};
  border-radius: 5px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`,X=l`
  cursor: pointer;

  &:hover {
    opacity: 0.5;
  }
`;function Y(e){function t(){const r=e.value?(parseFloat(e.value)+1).toFixed(2):1;e.handleChange(r)}function n(){const r=e.value?(parseFloat(e.value)-1).toFixed(2):0,t=r>=1?r:null;e.handleChange(t)}return r(R,{get children(){return[r(b,{src:y,onClick:t,className:X}),r(b,{src:C,onClick:n,className:X})]}})}function j(e){const t=r=>{e.setValue(r.target.value)};return r(B,{get children(){return[r(F,{children:"Cantidad que desea Recibir :"}),r(M,{get children(){return[r(k,{children:"$"}),r(z,{type:"number",placeholder:"0,00",get value(){return e.currentValue},onInput:t}),r(Y,{get value(){return e.currentValue},get handleChange(){return e.setValue}})]}})]}})}const S=e=>{const r=Intl.NumberFormat("en-US",{style:"decimal",currency:"USD"});return e?r.format(e):null},Z=e("div")`
  margin-top: 0.75rem;
  display: flex;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  text-align: center;
`,Q=e("span")`
  font-size: 12px;
  color: ${({theme:e})=>e.colors.secondary};
  user-select: none;
`,N=e("div")`
  display: flex;
  justify-content: center;
  width: 100%;
  height: 80px;
`,H=e("button")`
  font-size: 3.75rem;
  font-weight: 800;
  background-color: transparent;
  border-width: 0;
  color: ${({theme:e})=>e.colors.primary};
  margin: 0.3rem 0;
  cursor: pointer;
  padding: 0 0.55rem;
  height: 70px;

  &:hover {
    background-color: ${({theme:e})=>e.colors.copy};
    border-radius: 5px;
  }
`,T=e("p")`
  font-size: 14px;
  color: ${({theme:e})=>e.colors.secondary};
`,W=e("b")`
  color: ${({theme:e})=>e.colors.primary};
  margin-right: 2px;
`,q=e("div")`
  user-select: none;
`,P=e("div")`
  user-select: none;
`;function L(e){const[t,n]=s(!1);return d((()=>{e.prevResult&&(n(!0),setTimeout((()=>{n(!1)}),350))})),r(Z,{get children(){return[r(Q,{children:"Es necesario enviar:"}),r(N,{get children(){return[r(q,{get className(){return t()?"prev-animation":"prev-hide"},get children(){return r(H,{get children(){return S(e.prevResult)}})}}),r(P,{get className(){return t()?"result-animation":""},get children(){return r(H,{get children(){return S(e.result)}})}})]}}),r(T,{get children(){return["Comisión de"," ",r(W,{get children(){return["$",u((()=>S(e.commission)))]}}),"USD (5.4% + $0.30)"]}})]}})}var O={a:{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"},c:'<circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>'};const E=e("div")`
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`,D=e("div")`
  display: flex;
  align-items: center;
`,K=e("img")`
  width: auto;
  height: 40px;
`,V=e("img")`
  width: auto;
  height: 30px;
  margin-left: 10px;
`,U=e("button")`
  background-color: transparent;
  border-width: 0;
  cursor: pointer;
`,I=e("p")`
  font-size: 16px;
  margin-top: 1rem;
`,J=t("<b>PayPal</b>");function G(){const e=()=>{console.log("navigate to settings screen")};return[r(E,{get children(){return[r(D,{get children(){return[r(K,{src:"/assets/favicon.6938dee3.png"}),r(V,{src:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALwAAABACAYAAACgGR3JAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAxnSURBVHgB7Z0NsBZVGcefCwhkCBqkQiAXSSwtDFFT1ND8KLVgctAoZsQpZcYicRIlzamZoAE1hMh0HI2Rspo0lbCaTAv8xBARM0EE7r18KSnfqHzq6flz9mW2vXt2/2fvfZf76vnNPPe97+5zzu45e/Z8POc55xUJBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEPggU+c6YYzpqB+TVQaodJBi7FXZqbJBZa3KIpXH6+rq9kigRejzOVo/JqkcJsXZpfKuyhuRPKbP5iWpQTQ/rtCPYSoHOVTWqYzLimCGqQ67VR5U+ZIECqP512iqw3qVn6v0lxpC73czkbbTsyKYZ6rPAyr1EvBC8+wwU302qtwkNYDeZxcyTSe4Iminss2UwzoTCr0Xml8XmPKYLW0cvceTiHS8p9K5nSOOPiqHSDn0UpmtN9NNAiwnSHkM12czRdo2xxA6L+v4ZKerwPeVcsEDHCMBliOlXK42ru5A2+BEQqcBf1wFvl7KZ7xmap0EGD4l5fIRlW9L2+VYQmcZ/rgK/BlSPoernCsBhoFSPl+TtsvHCZ19NbzLvn60cOCtiffvOqt8TGwLMUL8bcSw+T8mASfaCvbQj56k+p0qC6L/24utqfFMTlO5QPzordc+QvvB/5U2hN5TV+FavIVZkSw3HGdkxNFJ5TbjxyQJZKJ5dCqZl8tz4umn8orxo+yuVC56T6eQ946J1OZdmuhEPXc5cWaq1gSYxbteZZ7wtJdAHmztvirrpD6fRv34qooRns7S9uhB6Lyu6d2Nf9L68IOFcyXYkde86Xm4FswTnvckkMcXSL2mPAV9PujX/lt49krbg2l19lfMaQWenVJmM2qV8GyWQB6fIfVeIfUahedNaXucROjsz4u0mrxeOJ4n9Y4QnuV5Ctrl+px+XCL2zUZie4t9cbeorBD7gv1DZY7WYOti4Q4VW1hcrddu1X82cS0MwLMsIjs1zHNSEI2/u358OuOe9mr8TyeOHS4cL5J6vUk91O5vZSloejBZCX8VOHEhXYNUMKH4vgp6A3g+K1XmqPyl0s2Iwh4l2caSFaq/NuU4M+m0WDJu+l5yEDBBCFRvluHp74ijg8pYlZXGj5kqPaM4niP0r4xds6PKaiLML6UAxroHbCXi/34sTJ3KDsNBFWTVe4eMb0FGHMeo3GL83FE2qYyJ0tSP0IdrQPeUazN5eE5WBrAWmmGSn5ntDW8JWOGIY6jKUlOcRpUBKu8Suj+IXRcPYoPhYOzA8TQdYnhvxzGxcIPIMJT7teqdaXgmp4SHz9UPVbaY4tyqcgmp2y9x/a5kuM+6MgA16R4ykty+pLFvMMsDKeEnmNahidS7KHH9X5PhrhQPjG15GBYnwl1MhltK3sf9hmd4Imxfw7WaDEzLvV2lfeIevkiEW6vSyZUB/Q0HastMNwA9f5bK24bny7GwqF3vNuXTo0CGgoeFxPC12RrTvEb7ERn2npx7gDvtFMODQtMxFr6XqZ4/vounUtIx3jdccrDEzrAu1QGESVwcLwCadtT88LtAl+ejXHSyWuXx2HfM3l4h5YIB6IbEsX+JHQwfmhN2iKa/q4bflqVkbB/0FuGYGtnK4wzigjY3Seq18azhmYqFN5eJn/vInMoA01ivVjyreimXhpRjzJzEuviXZIFnTDzgRE345kQ8naX4UsDpkc1+XzdI7IRV2byaPKD3hAHdb/Xf7+aEheUEBeivOXp3CFdQHtZrT085zpqM0a++Nva9sxSfNEJBj7+kM8RaYMomrcAz9/Fk/EuHAhFUyKv1WFbqw52Gf/Qhwe31Jx5hYe7COlmYSFEbokXBS4vJM18X2gbHcSyAyCvw4GzJKPCatq/rx6WSD1q7qxznBghHSwp4khn6fJrwT1QZXeYRFi3efLFzNlgzixcWZmX48rQTP15LOfZJyWeZ84wpZ1lfHIwFhsSuzw7mAAZcAx3pwOj9Z8aPCY64YGnaSIR3zjrruXrDD5xHOeLoacoHFrZ20fVZMy3A2A1myi6OtMCM+YLx46hEHN3IcOmVhLEWmgZTLlfHrt9XZScZbrwQGL9CPzwjnmlkHMc5wj9Ehp+VcQ/DTLk0mmgOI7r+WDLcWyq5XWNjB86LyDj3pIQ/mQln7Ngl9QZgodlrygE7F1yVuP6NZNjbhER1Dza8NeH0jHjOJeO4KSXs5WRYtADdMu7hBlMesMokLUQvEeFQwM4T/vkMMRzLUsKOIsI1myyL96PQZJThrYi+8lDtF96ZOD6CCIv+LTXDC/Qa2HOFWYS8Q9L7iBVgrWF8gv5vAYuxi9PvIMLB4jVO73drhk5Zyy7/oDIwbiEydnkfs+jkLg1Hr2eIXDleJ1RXphwbLPk0c1VJFvhqskQFXZHjNKHz4yeigsGY3KYU2MSJcaKCmdXpJ6Lntku+BQYM1bTs8x0y1kx7u9hFF3lM1Gv8KUeHGaAVBZYY+B+dp/cxUmVT4jxrwrxV/Mn1n5J0vy3GS7KZY1wHzwh8QG2FGhmTMjD+P6MZucOhe7Jw/FOqA+MFOFPc1pM4Z4mtJTE+uYjQhwXjZkKvNRdRwwSMNKOr8JDKXH02WRXDVySfxRqHj2dsBaYCS7O0MH7wmQWetcGjCYKdPC2DkJGYqNmiiX9beBiPt00a5zLx5xOETm4to9deqLX2esk3d45UPSwn+6nkA///EVHXy4nGhzQwDxjMVZko6a7WWJSD1mp9Zd6DhPF4fVqKwUwerY5/Mdbzlamgn0keiBf4fsJxnWbW76R16U7obJNiDCV02P0Uf6NyXY7OmSr3CTfLjLxkmnT22cB99tKUGeOW0ofQ8ang9mGs+/XxOWp4MZMtBwo7s29SM4fEio0VBb9eOJi+rC9M4fDeNNRYd+OzCdX/CMeDhA5e3lMJPdQ+04WjF6m3rAqFHTAz6GwLFOcaQqdB07QmcYxZE7A2rRWrDFpRgzAWmu0ayRZpfZjmFRMN5wiJsZ51M0h1qqukaYe1ZoW0HOThqKQ/UgZsun1WL/nAPJ8LjcvmnUJkqBhLqK5JOcZ0Z1KfU6XAMzUSoNxOC8DWStcKzw0qFxJ6Ozxf4j9KyxnvOcBjnfqqtdX1JkIHrRDldhD1wR8VrtVuSjnGWPQWpR2sFHjW5FWtGoR9+FgllLnPoZ4/UgU1+0ThWCx+3C8tA45hvxI/2C6Nb1pY2IruF3kTT3oefXYM6lm/oJdTjlF7SaYdrDRBrBceu47Vl7+JNU8dROhiUcjFYl2I0RWBDwu6L2jmsMcgzIE+jm0LPHTRrXlRr48+P7uYOg7ulem37kevhTxhC0e1KqR5KsMJvYNV/q73jErhXrEOY7AKwacGE1cjVc4XP6/atLW5TJdmjfOM3uAKw8F0EQqhcT9hDgz0zG3sXm82xWBmk5PXYraCBrulSmjcfcyBo0/iXlinsdRWAGsSfSw0K6V6TJUDw6vizyzx525tHYr0/9nand2Ww5vIStLapmiGXSkWGmaSEl3kprQT6MP7WGiKTPyw/FnlWSkf7zRpPsBNosEjCLoaPn7+cdgB60KpLnCMe0fKZUnKMWbA2uhyQUGBZwesRWpCGr1BLOaAL/hWaR2YAomXuGi67vHQHe3YU4WBdRqrZutb2ZqvtVaiYbae2ZT1hZRjzPYjzv47CvwpwrFRqky0sgaj/CI+GRVg4rxcOL+blrzE7O67kzRdT0lxhpB6r0mV0XTA87NoS1UBrThWPHUhdNMqLaaLt8R5Rvvwd5GDgNI2xDd2hdDzxo/3jf11wGOjOB4hwkyTAhhutTzAiqEW/ciD4X6dDhwvJaHX+pbKKuMH0nG9sYNO9kfITku5NrM1iNPRDtthoMnEW9vRoYNZtvnR210qxu4T802xpizX1DVsxHCtnRXvnhi7dPB7jjBIE/ruUzM8OF33hBcKEzydclQxmTU42rC0MHq9b4jdAcIFHNDwfArtgFYUY40d31GBiRh57TIpw+QMd5SZWBQfCw/z7OcdYfB8HlX9+1Kui+1cRjvC7YrC/d5xXmriJ2aizMXgDV578C9HVwz+69gG+Q0pCWNXJC0SbiB5o97bZPkQoPmCZ4INAPDjBFg8jgEjtsdYF60lCNQihre/PyGBQC2jhfh8srC/aRLrQQOBmsLYHRUayQI/TgKBWkYL8WyysD8igUAto4X4GrKwN5nEZqyBQE1h7Eb9rB18tAQCtYwW4rlkYb9dAoFaRwvyj4nC/qSxP44bqAH+B6tKljhk7hjpAAAAAElFTkSuQmCC"})]}}),r(U,{onClick:e,get children(){return r(b,{src:O,color:"#FFF",size:"2rem"})}})]}}),r(I,{get children(){return["Calculadora de comisiones de ",J.cloneNode(!0)]}})]}const $={false:"Recibir",true:"Enviar"},_=e("div")`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 0.3rem 0;
  font-size: 14px;
`,ee=e("span")`
  display: flex;
  flex-direction: row;
  align-items: center;
`,re=e("b")`
  margin-left: 3px;
`,te=e("button")`
  background-color: ${e=>e.active?e.theme.colors.fieldBorder:e.theme.colors.secondary};
  width: 56px;
  height: 28px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  cursor: pointer;
  border: 0;
`,ne=e("div")`
  background-color: ${({theme:e})=>e.colors.primary};
  width: 20px;
  height: 20px;
  border-radius: 14px;
  animation-duration: 0.25s;
  animation-timing-function: linear;
`;function oe(e){function t(){e.handleSwitch((e=>!e))}return r(_,{get children(){return[r(ee,{get children(){return["Tipo de conversión: ",r(re,{get children(){return $[e.active]}})]}}),r(te,{get active(){return e.active},onClick:t,get children(){return r(ne,{get active(){return e.active},get className(){return e.active?"indicator-on":"indicator-off"}})}})]}})}function ie(e){const r=Number(5.4);function t(e){const t=parseFloat(e);return parseFloat(100*(.3+t)/(0-r+100)).toFixed(2)}function n(e){const r=function(e){const r=parseFloat(e),n=t(r);return parseFloat(Math.round(100*n)/100-r).toFixed(2)}(e);return{totalResult:t(e),totalCommission:r}}function o(e){const t=function(e){const t=parseFloat(e);return parseFloat(r/100*t+.3).toFixed(2)}(e);return{totalResult:e-t,totalCommission:t}}const{totalCommission:i,totalResult:a}=function(e,r){if(0===function(e){if("string"==typeof e&&!isNaN(e)&&null!=e&&""!==e&&0!==e.charAt(0))return e;return 0}(e))return{totalCommission:0,totalResult:0};const{totalResult:t,totalCommission:i}=r?o(e):n(e);return{totalCommission:i,totalResult:t}}(e.value,e.type);return{result:a,commission:i}}function ae(){const[e,t]=s(!1),[n,o]=s(0),[i,a]=s(),[c,l]=s(),[h,g]=s();return d((()=>{const r=ie({value:n(),type:e()});a((e=>(g(String(e)),r.result))),l(String(r.commission))})),r(f,{get children(){return[r(G,{}),r(v,{}),r(oe,{get active(){return e()},handleSwitch:t}),r(v,{}),r(j,{get currentValue(){return n()},setValue:o}),(()=>{const e=u((()=>!!i()),!0);return r(m,{get when(){return e()&&c()},get children(){return r(L,{get prevResult(){return h()},get result(){return i()},get commission(){return c()}})}})})()]}})}const ce=h`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
`,le={colors:{primary:"#fcfcfd",secondary:"#9f9eba",main:"#0D3883",fieldBg:"#0e0558",fieldBorder:"#3b6efe",bg:"#090043",separator:"#201b61",copy:"rgba(255, 255, 255, 0.2)",currency:"rgb(107, 114, 128)"}};g((()=>r(p,{theme:le,get children(){return[r(ce,{}),r(ae,{})]}})),document.getElementById("root"));
